//grass
drawGrass();
function drawGrass() {
  penRGB(0, 170, 30);
  dot(1000);
}
//water/pond
drawPond();
function drawPond() {
  penRGB(0, 150, 200);
  dot(125);
  moveTo(70, 250);
  dot(70);
  moveTo(270, 300);
  dot(70);
}
//lilypads and lilypads with flowers 
drawLilypads(randomNumber(17, 19));
function drawLilypads(size) {
  for (var i = 0; i < 2; i++) {
    penUp();
    moveTo(randomNumber(20, 290), randomNumber(200, 310));
    penDown();
    penRGB(150, 220, 70);
    dot(size);
    turnTo(250);
    penUp();
    moveForward(5);
    penDown();
    penWidth(7);
    penRGB(0, 150, 200);
    moveForward(14);
    moveBackward(14);
    turnTo(280);
    moveForward(14);
    moveBackward(14);
  }
}
drawLilypadswithflowers(8);
drawLilypadswithflowers(14);
function drawLilypadswithflowers(size) {
  for (var i = 0; i < 3; i++) {
    drawLilypads(17);
    turnTo(80);
    moveForward(15);
    penDown();
    penColor("pink");
    dot(size);
    penColor("yellow");
    dot(4);
    penUp();
  }
}
//Cattail and cattail leaves
drawCattails();
function drawCattails() {
  drawTopcattailleaves();
  drawBottomcattailleaves();
}
function drawCattailleaves() {
  penDown();
  penWidth(3);
  penRGB(0, 220, 0);
  moveForward(40);
  arcRight(90, 13);
  turnLeft(180);
  arcLeft(90, 13);
  moveForward(40);
  turnTo(320);
  moveForward(25);
  moveBackward(25);
  turnTo(30);
  moveForward(40);
  moveBackward(40);
  penUp();
}
function drawTopcattailleaves() {
  for (var i = 0; i < 20; i++) {
    moveTo(randomNumber(0, 300), randomNumber(100, 200));
    drawCattailleaves();
    drawBrowncattail();
  }
}
function drawBottomcattailleaves() {
  for (var i = 0; i < 20; i++) {
    moveTo(randomNumber(0, 300), randomNumber(330, 420));
    drawCattailleaves();
    drawBrowncattail();
  }
}
function drawBrowncattail() {
  turnTo(340);
  penDown();
  moveForward(40);
  penColor("brown");
  penWidth(10);
  moveForward(15);
  penUp();
}

